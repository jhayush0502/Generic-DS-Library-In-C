#ifndef __TM_HEAP__H
#define __TM_HEAP__H 123
#include<tm_common.h>
#include<tm_array.h>
typedef struct __$__tm_heap
{
Array *array;
int (*comparator)(void *,void *);
int size;
}Heap;

Heap * createHeap(int (*comparator)(void *,void *),bool *success);
void addToHeap(Heap *heap,void *elem,bool *success);
void * removeFromHeap(Heap *heap,bool *success);
void * elementAtTopOfHeap(Heap *heap,bool *success);
int getSizeOfHeap(Heap *heap);
void destroyHeap(Heap *heap);
#endif
