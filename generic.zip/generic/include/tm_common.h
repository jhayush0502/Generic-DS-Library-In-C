#ifndef __TM_COMMAN__H
#define __TM_COMMAN__H
#define TRUE 1
#define True 1
#define true 1
#define FALSE 0
#define False 0
#define false 0
#define bool int
#define boolean int
#endif