#ifndef __TM_ARRAY__H
#define __TM_ARRAY__H 123
#include<tm_common.h>
typedef struct __$__tm_array
{
int rows;
void ***ptr;
int size;
}Array;

Array * createArray(bool *success);
int getSizeOfArray(Array *array);
void setElementOfArray(Array *array,int index,void *ptr,bool *success);
void * getElementFromArray(Array *array,int index,bool *success);
void destroyArray(Array *array);
#endif
