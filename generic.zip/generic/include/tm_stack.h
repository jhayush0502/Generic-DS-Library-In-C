#ifndef __TM_STACK__H
#define __TM_STACK__H 123
#include<tm_sll.h>
#include<tm_common.h>
typedef struct __$__tm_stack
{
SinglyLinkedList *singlyLinkedList;
}Stack;

Stack * createStack(bool *success);
void pushOnStack(Stack *stack,void *ptr,bool *success);
void * popFromStack(Stack *stack,bool *success);
int getSizeOfStack(Stack *stack);
void * elementAtTopOfStack(Stack *stack,bool *success);
bool isStackEmpty(Stack *stack);
void destroyStack(Stack *stack);
void clearStack(Stack *stack);
#endif
