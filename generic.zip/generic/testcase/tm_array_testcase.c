#include<tm_array.h>
#include<stdio.h>
int main()
{
Array *array;
bool succ;
int i;
int *ptr;
array=createArray(&succ);
if(!succ)printf("Low On Memory\n");
setElementOfArray(array,0,(void *)224,&succ);
if(succ)printf("address added that catain 224\n");
else printf("address not added that cantain 224\n");
setElementOfArray(array,234,(void *)45666,&succ);
if(succ)printf("address added that catain 224\n");
else printf("address not added that cantain 224\n");
setElementOfArray(array,132,(void *)89700,&succ);
if(succ)printf("address added that catain 224\n");
else printf("address not added that cantain 224\n");
setElementOfArray(array,124,(void *)34522,&succ);
if(succ)printf("address added that catain 224\n");
else printf("address not added that cantain 224\n");
setElementOfArray(array,4563,(void *)202020,&succ);
if(succ)printf("address added that catain 224\n");
else printf("address not added that cantain 224\n");
printf("Array size is : %d",getSizeOfArray(array));
for(i=0;i<getSizeOfArray(array);i++)
{
ptr=(int *)getElementFromArray(array,i,&succ);
printf("(%d--->%d)",i,*ptr);
}
destroyArray(array);
return 0;
}